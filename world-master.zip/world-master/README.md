# World

Football data includes:

- Brazil (Brasil) incl.  Campeonato Brasileiro Série A / Brasileirão etc.
- Mexico incl. Liga MX, etc.



## Sources

The datasets are a 1:1 mirror, that is, an export in the comma-separated values (CSV) format from the [open football.db datasets](https://github.com/openfootball).



## Questions? Comments?

Yes, you can. More than welcome.
See [Help & Support »](https://github.com/openfootball/help)

