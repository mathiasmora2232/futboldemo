# United States (and Canada) - Major League Soccer (MLS)

Football data for the United States (and Canada) includes

- Major League Soccer (MLS)


## Questions? Comments?

Send them along to the
[Open Sports & Friends Forum/Mailing List](http://groups.google.com/group/opensport).
Thanks!
