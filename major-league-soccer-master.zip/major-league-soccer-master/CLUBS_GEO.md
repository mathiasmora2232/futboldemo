# Clubs by Geo(graphy)

- **Carson** (2): 
  - CD Chivas USA (2005-2014)  (2) Chivas USA · Club Deportivo Chivas US
  - LA Galaxy  (1) Los Angeles Galaxy
- **Bridgeview** (1): Chicago Fire  (2) Chicago · Chicago Fire Soccer Club
- **Chester** (1): Philadelphia Union  (1) Philadelphia
- **Columbus** (1): Columbus Crew SC  (2) Columbus · Columbus Crew
- **Commerce City** (1): Colorado Rapids  (1) Colorado
- **Fort Lauderdale** (1): Miami Fusion (1998-2001) 
- **Foxborough** (1): New England Revolution  (3) New England · N.E. Revolution · New England Rev.
- **Frisco** (1): FC Dallas  (1) Dallas
- **Harrison** (1): New York Red Bulls  (3) NY Red Bulls · New York Metrostars · Metrostars
- **Houston** (1): Houston Dynamo  (2) Houston · H. Dynamo
- **Kansas City** (1): Sporting Kansas City  (3) Sp. Kansas City · Sporting KC · Kansas City Wizards
- **Montréal** (1): Montreal Impact  (4) Montreal · Montreal I. · Impact Montréal · Impact de Montréal
- **New York City** (1): New York City FC  (2) NYC FC · New York City
- **Orlando** (1): Orlando City SC  (2) Orlando · Orlando City
- **Portland** (1): Portland Timbers  (1) Portland
- **San Jose** (1): San Jose Earthquakes  (3) San Jose · SJ Earthquakes · Earthquakes
- **Sandy** (1): Real Salt Lake  (1) Real Salt Lake City
- **Seattle** (1): Seattle Sounders FC  (2) Seattle · Seattle Sounders
- **Tampa** (1): Tampa Bay Mutiny (1996-2001) 
- **Toronto** (1): Toronto FC  (3) TFC · Toronto · FC Toronto
- **Vancouver** (1): Vancouver Whitecaps FC  (3) Vancouver · Vancouver W'caps · Vancouver Whitecaps
- **Washington** (1): D.C. United  (1) Washington D.C. United


